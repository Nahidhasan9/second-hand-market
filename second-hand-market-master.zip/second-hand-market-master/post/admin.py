from django.contrib import admin
from .models import PostAd, LocationCategoryModel, PostCategory

# Register your models here.


admin.site.register(PostAd)
admin.site.register(LocationCategoryModel)
admin.site.register(PostCategory)
