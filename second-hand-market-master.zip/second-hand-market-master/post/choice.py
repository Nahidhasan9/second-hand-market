LOCATION_CHOICE = {
    'DHAKA': 'Dhaka',
    'CHATTOGRAM': 'Chattogram',
    'KHULNA': 'Khulna',
    'BARISHAL': 'Barishal',
    'RAJSHAHI': 'Rajshahi',
    'RANGPUR': 'Rangpur',
    'MYMENSINGH': 'Mymensingh',
}
